package controller;

public enum StepType {
    Walk, Bus
}
