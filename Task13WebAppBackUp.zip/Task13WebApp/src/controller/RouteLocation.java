package controller;

public class RouteLocation {
    public String Latitute, Longitute;
    public String Name;
}
