package controller;

public class RouteStep {
    public StepType Type;
    public RouteLocation StartPos, EndPos;
    public String BusRoute, FullRouteName;
    public int Duration;
}
