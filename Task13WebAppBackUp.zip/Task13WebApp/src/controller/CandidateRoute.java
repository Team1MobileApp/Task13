package controller;

import java.util.ArrayList;
import java.util.List;

public class CandidateRoute {
    public List<RouteStep> Steps;
    public CandidateRoute()
    {
        Steps = new ArrayList<RouteStep>();
    }
}
